import React from "react";

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2023 Your Website</p>
    </footer>
  );
};

export default Footer;
