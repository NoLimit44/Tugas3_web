import React from "react";
import "./styles.css"; // Import CSS file

const Contact = () => {
  return (
    <div className="text-box">
      {" "}
      {/* Tambahkan class "text-box" */}
      <h1>Contact Page</h1>
      {/* Isi konten Contact di sini */}
    </div>
  );
};

export default Contact;
