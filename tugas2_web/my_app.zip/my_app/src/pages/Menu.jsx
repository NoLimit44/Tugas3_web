import React from "react";
import "./styles.css"; // Import CSS file

const Menu = () => {
  return (
    <div className="text-box">
      {" "}
      {/* Tambahkan class "text-box" */}
      <h1>Menu Page</h1>
      {/* Isi konten Menu di sini */}
    </div>
  );
};

export default Menu;
